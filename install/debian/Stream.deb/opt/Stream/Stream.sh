java -jar /opt/Stream/Stream.jar
